#include <string>

using namespace std;

// -1: a<b	0: a=b	1: a>b
int compare2strings(string a, string b);