1. 學號：b04901117
2. 姓名：毛弘仁
3. 使用之程式語言：< C++ >
4. 使用之編譯器：< Apple LLVM version 10.0.0 (clang-1000.11.45.2) >
5. 檔案壓縮方式: <zip -r b04901117_p1_v1.zip b04901117_p1_v1/>
6. 各檔案說明：
	 xxxSort 的 executable binaries 為 OSX 編譯後的執行檔
	 src/ 底下的 .cpp 及 .h 檔案為原始碼
	 src/ 底下的 make_xxxSort 為編譯原始碼的指令
	 report.doc 為程式報告

7. 編譯方式說明：        	
	 cd 進 src/ 資料夾，在 command line 執行 source make_xxxSort，
	 即可編譯 xxxSort 的 executable binary（會編譯到 src/ 資料夾裡面）。

8. 執行、使用方式說明：
	 在 command line 輸入 ./<executable_file_name> <input_file_name> <output_file_name>
	 例如：./quickSort case1.dat output.dat

9. 執行結果說明（說明執行結果的觀看方法，及解釋各項數據等）：	
	 輸出 <output_file_name> 之外，程式會另外在 command line 上面顯示以下資訊：

	 Number of words: xxxx
	 DONE!



       


